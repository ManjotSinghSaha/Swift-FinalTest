//
//  WorkOrderViewController.swift
//  Manjot-Singh-Saha_COMP2125-001_Final-Term
//
//  Created by Manjot Singh Saha on 2020-08-04.
//  Copyright © 2020 Manjot Singh Saha. All rights reserved.
//

import UIKit

class WorkOrderViewController: UIViewController {

    @IBOutlet weak var lblWname: UILabel!
    @IBOutlet weak var lblWrate: UILabel!
    @IBOutlet weak var lblWemolyeename: UILabel!
    @IBOutlet weak var lblWtotalcost: UILabel!
    @IBOutlet weak var lblSubmit: UILabel!
    
    // Declaring varaible for segue to work
    var project_name:String = ""
    var employee_name:String = ""
    var emolyee_duration:String = ""
    var employee_cost:String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        lblWname.text = project_name;
        // lblWemolyeename.text = "Employee Name: " + employee_name;
        lblWtotalcost.text = employee_cost
    }

    @IBAction func btnSubmit(_ sender: UIButton) {
        lblSubmit.text = "Thanks for the order, looking forward working with you"
    }
}
