//
//  ViewController.swift
//  Manjot-Singh-Saha_COMP2125-001_Final-Term
//
//  Created by Manjot Singh Saha on 2020-08-04.
//  Copyright © 2020 Manjot Singh Saha. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var lblProjectId: UITextField!
    @IBOutlet weak var lblPname: UITextField!
    @IBOutlet weak var lblPduration: UITextField!
    @IBOutlet weak var lblPrate: UITextField!
    @IBOutlet weak var btnNext: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func btnNext(_ sender: UIButton) {
        performSegue(withIdentifier: "segueToResource", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var vc = segue.destination as! ResourceViewController

        vc.projectName = lblPname.text! 
        vc.projectDuration = lblPduration.text!
        vc.projectRate = lblPrate.text!
    }
    
}

