//
//  ResourceViewController.swift
//  Manjot-Singh-Saha_COMP2125-001_Final-Term
//
//  Created by Manjot Singh Saha on 2020-08-04.
//  Copyright © 2020 Manjot Singh Saha. All rights reserved.
//

import UIKit

class ResourceViewController: UIViewController {

    @IBOutlet weak var lblEid: UITextField!
    @IBOutlet weak var lblEname: UITextField!
    @IBOutlet weak var lblEduration: UITextField!
    @IBOutlet weak var lblErate: UITextField!
    @IBOutlet weak var lblEmployeeRate: UILabel!
    
    @IBOutlet weak var messagePname: UILabel! // show Project Name
    @IBOutlet weak var messageEname: UILabel! // show Employee Name
    @IBOutlet weak var messageRate: UILabel!  // show Hiring Rate
    
    // Declared varaiables
    var projectName:String = ""
    var projectDuration:String = ""
    var projectRate:String = ""
    var duration:Double = 0.0
    var rate:Double = 0.0
     
    override func viewDidLoad() {
        super.viewDidLoad()
        lblEmployeeRate.text = String(projectRate) // show hiring rate
    }
    

    @IBAction func btnSave(_ sender: UIButton) {
        messagePname.text = "Project Name: " + projectName
        messageEname.text = "Employee Name: " + lblEname.text!
        
        
        duration = Double (projectDuration) as! Double;
        rate = Double (projectRate) as! Double;
        
        if(duration > 100 || duration < 50) {
            duration = 50 // set to default
        }
        if (rate > 150 || rate < 30) {
            rate = 30 // set to default
        }
        
        var totalCost = duration * rate;
        
        messageRate.text = "Total Cost: " + String(totalCost);
        
    }
    
    
    // Segue to Work Order page
    @IBAction func btnContinue(_ sender: UIButton) {
        performSegue(withIdentifier: "segueToWorkOrder", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var rvc = segue.destination as! WorkOrderViewController

        rvc.employee_name = lblEname.text!
        rvc.employee_cost = messageRate.text!
        rvc.project_name = messagePname.text!
    }
}
